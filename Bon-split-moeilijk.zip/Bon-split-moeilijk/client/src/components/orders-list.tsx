import { useState } from "react";
import { Minus, Plus, Trash2, List, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Order } from "@shared/schema";

interface OrdersListProps {
  orders: Order[];
  totalItems: number;
  isLoading: boolean;
  people: string[];
  onPeopleChange: (people: string[]) => void;
}

const colorClasses = {
  primary: "bg-primary-100 text-primary-700",
  amber: "bg-amber-100 text-amber-700", 
  purple: "bg-purple-100 text-purple-700",
  emerald: "bg-emerald-100 text-emerald-700",
  red: "bg-red-100 text-red-700",
  blue: "bg-blue-100 text-blue-700",
};

export default function OrdersList({ orders, totalItems, isLoading, people, onPeopleChange }: OrdersListProps) {
  const [newPersonName, setNewPersonName] = useState("");
  const [showAddPerson, setShowAddPerson] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: string; quantity: number }) => {
      const response = await apiRequest("PATCH", `/api/orders/${id}`, { quantity });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error) => {
      toast({
        title: "Fout bij bijwerken bestelling",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const deleteOrderMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/orders/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Bestelling verwijderd",
      });
    },
    onError: (error) => {
      toast({
        title: "Fout bij verwijderen bestelling",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleIncrement = (order: Order) => {
    updateOrderMutation.mutate({ id: order.id, quantity: order.quantity + 1 });
  };

  const handleDecrement = (order: Order) => {
    if (order.quantity > 1) {
      updateOrderMutation.mutate({ id: order.id, quantity: order.quantity - 1 });
    } else {
      deleteOrderMutation.mutate(order.id);
    }
  };

  const handleDelete = (order: Order) => {
    deleteOrderMutation.mutate(order.id);
  };

  const addPerson = () => {
    if (newPersonName.trim() && !people.includes(newPersonName.trim())) {
      onPeopleChange([...people, newPersonName.trim()]);
      setNewPersonName("");
      setShowAddPerson(false);
      toast({
        title: "Persoon toegevoegd",
        description: `${newPersonName.trim()} is toegevoegd aan de groep`,
      });
    }
  };

  const removePerson = (personName: string) => {
    onPeopleChange(people.filter(p => p !== personName));
    toast({
      title: "Persoon verwijderd",
      description: `${personName} is verwijderd uit de groep`,
    });
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <List className="text-emerald-500 text-lg" />
          <h2 className="text-lg font-semibold text-slate-800">Huidige Bestellingen</h2>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-16 bg-slate-100 rounded-lg"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <List className="text-emerald-500 text-lg" />
          <h2 className="text-lg font-semibold text-slate-800">Huidige Bestellingen</h2>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAddPerson(!showAddPerson)}
            className="text-sm"
          >
            <UserPlus size={16} className="mr-1" />
            Persoon toevoegen
          </Button>
          <span className="text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            {totalItems} items
          </span>
        </div>
      </div>

      {/* Add person section */}
      {showAddPerson && (
        <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex gap-2">
            <Input
              placeholder="Naam van persoon..."
              value={newPersonName}
              onChange={(e) => setNewPersonName(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && addPerson()}
              className="flex-1"
            />
            <Button onClick={addPerson} disabled={!newPersonName.trim()} size="sm">
              Toevoegen
            </Button>
            <Button variant="ghost" onClick={() => setShowAddPerson(false)} size="sm">
              Annuleren
            </Button>
          </div>
        </div>
      )}

      {/* People list */}
      {people.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {people.map((person) => (
              <div key={person} className="flex items-center gap-2 bg-slate-100 rounded-lg px-3 py-1">
                <span className="text-sm font-medium">{person}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removePerson(person)}
                  className="h-auto p-1 text-slate-500 hover:text-red-500"
                >
                  <Trash2 size={12} />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {orders.length === 0 ? (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <List className="text-slate-400 text-xl" />
          </div>
          <p className="text-slate-600 font-medium">Nog geen bestellingen</p>
          <p className="text-sm text-slate-500 mt-1">Voeg hierboven je eerste bestelling toe</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div key={order.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
              <div className="flex-1">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${colorClasses[order.userColor as keyof typeof colorClasses] || colorClasses.primary}`}>
                    <span className="text-xs font-semibold">{order.userInitial}</span>
                  </div>
                  <div>
                    <span className="font-medium text-slate-800">{order.userName}</span>
                    <span className="text-slate-600 ml-2">{order.itemName}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDecrement(order)}
                    disabled={updateOrderMutation.isPending || deleteOrderMutation.isPending}
                    className="w-8 h-8 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center transition-colors border-0 p-0"
                  >
                    <Minus className="text-xs text-slate-600" size={12} />
                  </Button>
                  <span className="w-8 text-center font-medium text-slate-800">{order.quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleIncrement(order)}
                    disabled={updateOrderMutation.isPending}
                    className="w-8 h-8 rounded-full bg-emerald-100 hover:bg-emerald-200 flex items-center justify-center transition-colors border-0 p-0"
                  >
                    <Plus className="text-xs text-emerald-600" size={12} />
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(order)}
                  disabled={deleteOrderMutation.isPending}
                  className="text-red-400 hover:text-red-600 p-2 transition-colors"
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}


    </div>
  );
}
